param (
    [Parameter(Mandatory = $true)]
    [ValidateSet("Baseline", "Scan")]
    [string]$Mode,

    [Parameter(Mandatory = $true)]
    [string]$Path,

    [Parameter(Mandatory = $true)]
    [string]$BaselinePath,

    [string]$OutputPath
)


# BASELINE MODE
 
if ($Mode -eq "Baseline") {

    $files = Get-ChildItem -Path $Path -Recurse -File

    $results = foreach ($file in $files) {
        $hash = Get-FileHash -Path $file.FullName -Algorithm SHA256
        [PSCustomObject]@{
            Path = $file.FullName
            Hash = $hash.Hash
        }
    }

    $results | Export-Csv -Path $BaselinePath -NoTypeInformation
    Write-Host "Baseline created at $BaselinePath"
}


# SCAN MODE

if ($Mode -eq "Scan") {

    $baseline = Import-Csv $BaselinePath
    $baselineTable = @{}

    foreach ($item in $baseline) {
        $baselineTable[$item.Path] = $item.Hash
    }

    $files = Get-ChildItem -Path $Path -Recurse -File
    $changedFiles = @()

    foreach ($file in $files) {
        $currentHash = (Get-FileHash -Path $file.FullName -Algorithm SHA256).Hash

        if (-not $baselineTable.ContainsKey($file.FullName)) {
            $changedFiles += [PSCustomObject]@{
                Path = $file.FullName
                Hash = $currentHash
                Status = "New"
            }
        }
        elseif ($baselineTable[$file.FullName] -ne $currentHash) {
            $changedFiles += [PSCustomObject]@{
                Path = $file.FullName
                Hash = $currentHash
                Status = "Modified"
            }
        }
    }

    $changedFiles | Export-Csv -Path $OutputPath -NoTypeInformation
    Write-Host "Scan complete. Output saved to $OutputPath"
}
