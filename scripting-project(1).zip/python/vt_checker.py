import csv
import requests
import configparser

# load config
config = configparser.ConfigParser()
config.read("../config/config.ini")

API_KEY = config["virustotal"]["api_key"]
INPUT_CSV = config["paths"]["input_csv"]
OUTPUT_CSV = config["paths"]["output_csv"]

MALICIOUS_THRESHOLD = 5

HEADERS = {"x-apikey": API_KEY}
VT_URL = "https://www.virustotal.com/api/v3/files/{}"


def main():
    print(f"Using input CSV: {INPUT_CSV}")
    print(f"Using output CSV: {OUTPUT_CSV}")
    print(f"Malicious threshold: {MALICIOUS_THRESHOLD}")

    # read changed files
    with open(INPUT_CSV, newline="", encoding="utf-8") as f:
        reader = csv.DictReader(f)
        files = list(reader)

    results = []

    high_risk = 0
    medium_risk = 0
    low_risk = 0
    unknown = 0

    # query virustotal
    for i, file in enumerate(files, start=1):
        file_hash = file.get("Hash", "")
        status = file.get("Status", "Unknown")

        display_path = file.get("FileName") or file.get("Path") or "None"

        print(f"[{i}] Checking hash for {display_path} ({status})")

        malicious = "N/A"
        suspicious = "N/A"
        risk = "Unknown"

        try:
            r = requests.get(VT_URL.format(file_hash), headers=HEADERS, timeout=15)

            if r.status_code == 200:
                data = r.json()
                stats = data["data"]["attributes"]["last_analysis_stats"]
                malicious = stats.get("malicious", 0)
                suspicious = stats.get("suspicious", 0)

                if malicious >= MALICIOUS_THRESHOLD:
                    risk = "High"
                    high_risk += 1
                elif malicious > 0 or suspicious > 0:
                    risk = "Medium"
                    medium_risk += 1
                else:
                    risk = "Low"
                    low_risk += 1
            else:
                print(f"[!] VT query failed for {file_hash}: {r.status_code}")
                unknown += 1

        except Exception:
            print(f"[!] VT query failed for {file_hash}: error")
            unknown += 1

        results.append({
            "Path": file.get("Path", ""),
            "Hash": file_hash,
            "Status": status,
            "Malicious": malicious,
            "Suspicious": suspicious,
            "Risk": risk
        })

    # write csv report
    with open(OUTPUT_CSV, "w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=results[0].keys() if results else ["Path","Hash","Status","Malicious","Suspicious","Risk"])
        writer.writeheader()
        writer.writerows(results)


    # prints virus total summary
    print("\n=== Summary ===")
    print(f"Total files checked: {len(files)}")
    print(f"High risk: {high_risk}")
    print(f"Medium risk: {medium_risk}")
    print(f"Low risk: {low_risk}")
    print(f"Unknown: {unknown}")
    print(f"CSV report: {OUTPUT_CSV}")


if __name__ == "__main__":
    main()
