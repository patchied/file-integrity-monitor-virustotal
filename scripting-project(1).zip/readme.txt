README - Scripting for Cybersecurity Project
-------------------------------------------------
Project Name: File Integrity Monitoring and VirusTotal Analysis Tool
Developed by: Padraig Lance Omboy(B00175545) and Meso Ohaekelehem(B00172989)

-------------------------------------------------
Overview
--------------------------------------------------
This project automates a basic cybersecurity workflow using Powershell and Python.
Powershell is used to can a folder and record any details, specifically file hashes and to detect and new or modified files.
Python sends the file hashes to the VirusTotal API to check if they are asscociated with any malware.
The final output includes a csv and json report with the risk level results.

The goal is to help identify suspicious file changes and link them to any real threats via VirusTotal.

----------------------------------------------------
Folder structure
---------------------------------------------------

ScriptingProject/
	powershell/
		FileIntegrity.ps1
	python/
		vt_checker.py
		requirements.txt
	config/
		config.ini	(holds API key and file paths)
	sample_output/
		baseline.csv
		changed_files.csv
		vt_report.csv
		vt_report.json
	FIMTest/	(test folder with files to monitor)

-----------------------------------------------------
Setup Instructions
----------------------------------------------------
Step 1 - Install Python 3.10

Step 2 - Create virtual environment, run in cmd:
			cd python
			python -m venv venv
 
Step 3 - Install required modules:
			pip install requirements.txt

Step 4 - API Key:
		Change in config.ni: api_key = [your actual API key]

Step 5 - Make sure "sample_output" and "FIMTest" exist

-----------------------------------------------------
Running the Tool
-----------------------------------------------------
PART 1 – Create a baseline (PowerShell)

1. Open PowerShell
2. Navigate to the powershell folder, run in powershell:
       cd "<insert your own path here>\ScriptingProject\powershell"

3. Run the baseline command:
       .\FileIntegrity.ps1 -Mode Baseline -Path "C:\FIMTest" -BaselinePath "..\sample_output\baseline.csv"                         

This creates the baseline.csv file

PART 2 - Modify or add files to FIMTest folder, preferably ones you think are suspicious.

PART 3 – Run the scan (PowerShell)
	.\FileIntegrity.ps1 -Mode Scan -Path "C:\FIMTest" -BaselinePath "..\sample_output\baseline.csv" -OutputPath "..\sample_output\changed_files.csv"

This creates the changed_files.csv file

PART 4 - Run the Python analysis

1. Navigate to the python folder:
       cd "<insert your own path here>\ScriptingProject\python"

2. Activate the virtual environment:
       .\venv\Scripts\activate

3. Run the tool:
       python vt_checker.py

The script will:
- Read changed_files.csv
- Query VirusTotal
- Produce vt_report.csv and vt_report.json
- Print a summary in the terminal

----------------------------------------------------------
Required packages/ modules
----------------------------------------------------------
Python:
- requests
- configparser
(Installed automatically using requirements.txt)

Powershell:
- none

-------------------------------------------------------------
Notes
-------------------------------------------------------------
- Keep your VirusTotal API key private
- If the VirusTotal returns a 404 error it means the hash does not exist in their database
- If PowerShell is unable to run the script try:
	Set-ExecutionPolicy RemoteSigned -Scope CurrentUser

--------------------------------------------------------------
END OF READ ME
-------------------------------------------------------------
